
public class Example {

	public static void main(String[] args) {
		int i = 10; // Local variables
		String s = "Hello world";
		System.out.println(i);

		System.out.println(s);

		boolean b = true; // default value is false
		byte b1 = 126;
		short sh = 323;
		int i1 = 12387;
		float f = 123.65f; // averages
		long l = 23456789L;
		double d = 2345.43d; // amounts, price calculations
		char ch = 'a'; // '1', '@'

		System.out.println(b);
		System.out.println(b1);
		System.out.println(sh);

		System.out.println(i1);

		System.out.println(f);

		System.out.println(l);
		System.out.println(d);
		System.out.println(ch);

	}
}
