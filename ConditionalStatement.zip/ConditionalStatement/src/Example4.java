
public class Example4 {

	public static void main(String[] args) {
		char ch = 'u';

		switch (ch) {
		case 'a':
			System.out.println("vowels a");
			break;
		case 'e':
			System.out.println("vowels e");
			break;
		case 'i':
			System.out.println("vowels i");
			break;
		case 'o':
			System.out.println("vowels 0");
			break;
		case 'u':
			System.out.println("vowels u");
			break;
		default:
			System.out.println("consonants");
			break;
		}
	}
}
