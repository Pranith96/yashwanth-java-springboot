
public class Example1 {

	public static void main(String[] args) {
		int age = 18;
		if (age < 18) {
			System.out.println("age is lessthan 18");
			welcome();
		}

		System.out.println("Hello welcome");
	}

	public static void welcome() {
		System.out.println("Welcome to java");
	}
}
