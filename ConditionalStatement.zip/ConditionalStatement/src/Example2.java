
public class Example2 {

	public static void main(String[] args) {
		int age = 2;
		if (age < 18) {
			System.out.println("age is lessthan 18");
			welcome();
		} else {
			System.out.println("Hello welcome");
		}
	}

	public static void welcome() {
		System.out.println("Welcome to java");
	}
}
