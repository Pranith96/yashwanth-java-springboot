
public class Example2 {

	// static method without parameters and without return type
	public static void display_3() {
		System.out.println("display1 ");
	}

	// static method with parameters and without return type
	public static void displayWithParams_4(int num1, int num2, int num3) {

		int a = num1 + num2;
		int result = a * num3;
		System.out.println(result);
	}

	// static method with parameters and without return type
	public static void displayWithParams1_5(int num1, long num2, String word) {
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(word);
	}
}
